import {Prompter} from "../../utils/prompter.utils.js";
import {ColumnDetails} from "../../utils/Column.details.interface.js";
import {DEFAULT_PROPERTIES} from "../../utils/default.properties.js";
import fs from "fs";
// fs promisified
import * as fsp from 'fs/promises';
import readline from "readline";
import {WIZGEN_ENTITY_DEFINITION_FILE_PATH, WIZGEN_FOLDER} from "../../resources/constants/utils.constant.js";
import path from "path";
import { QuestionsKeysEnum } from "../../resources/global/translations.js";

import { appendFileSync } from "fs";

export interface EntityDefinition {
    entities: Entity[];
    version?: number;
}

export interface Entity {
    entityName: string;
    columns: ColumnDetails[];
}
export const useDefaultProperties = async (prompter: Prompter): Promise<ColumnDetails[]> => {
    const useDefaults = await prompter.ask(QuestionsKeysEnum.CONFIRM_DEFAULT_PROPERTIES) === 'yes';
    if (useDefaults) {
        return Object.values(DEFAULT_PROPERTIES).filter(prop => prop !== null && prop !== undefined) as ColumnDetails[];
    }
    return [];
};


export const getColumnDetails = async (prompter: Prompter): Promise<ColumnDetails[]> => {
    let columns: ColumnDetails[] = [];
    let addMoreColumns = true;

    while (addMoreColumns) {
        const columnName = await prompter.ask(QuestionsKeysEnum.COLUMN_NAME);

        if (columnName && DEFAULT_PROPERTIES.hasOwnProperty(columnName)) {
            const columnProperty = DEFAULT_PROPERTIES[columnName];
            if (columnProperty) {
                columns.push(columnProperty as ColumnDetails);
            }
        } else {
            const columnType = await prompter.ask(QuestionsKeysEnum.COLUMN_TYPE);
            const isPrimary = await prompter.ask(QuestionsKeysEnum.IS_PRIMARY) === 'yes';
            const isGenerated = await prompter.ask(QuestionsKeysEnum.IS_GENERATED) === 'yes';
            const isUnique = await prompter.ask(QuestionsKeysEnum.IS_UNIQUE) === 'yes';
            const isNullable = await prompter.ask(QuestionsKeysEnum.IS_NULABLE) === 'yes';

            columns.push(<ColumnDetails>{
                columnName: columnName,
                type: columnType,
                isPrimary,
                isGenerated,
                isUnique,
                nullable: isNullable,
                default: ""
            });
        }

        addMoreColumns = await prompter.ask(QuestionsKeysEnum.MORE_COLUMNS) === 'yes';
    }

    return columns;
};

export const saveEntityDefinition = async (data: EntityDefinition, filePath: string): Promise<void> => {
    try {
        // Ensure directory exists
        const dir = path.dirname(filePath);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }

        // Save the file
        fs.writeFileSync(filePath, JSON.stringify(data, null, 4));
        console.log(`Entity saved successfully at ${filePath}`);
    } catch (error) {
        console.error("Failed to save entity definition:", error);
    }
};


/**
 *  Choisir une entité à partir d'un fichier de définition d'entité et la modifier
**/
export const loadSchemaFromEntityName = async () => {
    try {
        // 1. Ouvrir le fichier schema.prisma
        const schema = await fsp.readFile('prisma/schema.prisma', 'utf8');

        // 2. Liste des entités (modèles Prisma)
        const entities: string[] = schema.split('\n')
            .filter((line: string) => line.startsWith('model '))
            .map((modelLine: string) => {
                const parts = modelLine.split(' ');
                return parts.length > 1 ? parts[1] : undefined;
            }).filter((name): name is string => !!name);

        // 3. Demander à l'utilisateur de choisir une entité
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });

        console.log('Entités disponibles :', entities.join(', '));
        const chosenEntity: string = await new Promise<string>((resolve) => {
            rl.question('Choisissez une entité : ', (answer: string) => {
                resolve(answer);
            });
        });
        rl.close();

        // 4. Récupérer le schéma de l'entité choisie
        const entitySchemaStart: number = schema.indexOf(`model ${chosenEntity} {`);
        const entitySchemaEnd: number = schema.indexOf('}', entitySchemaStart) + 1;
        const entitySchema: string = schema.substring(entitySchemaStart, entitySchemaEnd);

        // 5. Renvoyer le schéma de l'entité choisie
        return entitySchema;
    } catch (error) {
        console.error('Une erreur est survenue :', (error as Error).message);
        return null;
    }
};


export const listEntities = async () => {
    const prompter = new Prompter();
    const entitySchema = prompter.chooseEntity();
    // return entitySchema if entitySchema is != "Quit"
    return await entitySchema !== "Quit" ? entitySchema : null;
//
 }
/**
* Ouvre le fichier schema.prisma et renvoie le schéama de l'entité choisie
**/
export const modifyEntityDefinition = async() => {
    // on demande quelle entité il veut modifier
    const entitySchema = await listEntities();
    // on demande quelle colonne il veut modifier
    // on demande quelle propriété il veut modifier
    // on demande quelle valeur il veut modifier
    // on modifie la colonne
    // on modifie la propriété
    // on modifie la valeur

}
/**
 * Génère un fichier de définition d'entité
 * @returns {Promise<void>}
 * @constructor
 * @async
 */
export async function generateEntityDefinition() {
    const prompter = new Prompter();
    // 1. Poser une série de questions pour configurer le fichier de définition d'entité
    const entityName = await prompter.ask(QuestionsKeysEnum.ENTITY_NAME);
    const generateTable = await prompter.ask(QuestionsKeysEnum.GENERATE_TABLE);
    const tableName = await prompter.ask(QuestionsKeysEnum.TABLE_NAME, entityName as string);
    // 2. Poser une série de questions pour configurer les colonnes de l'entité
    const columns: ColumnDetails[] = [];
    let moreColumns = true;
    while (moreColumns) {
        const columnName = await prompter.ask(QuestionsKeysEnum.COLUMN_NAME);
        const columnType = await prompter.ask(QuestionsKeysEnum.COLUMN_TYPE);
        const isPrimary = await prompter.ask(QuestionsKeysEnum.IS_PRIMARY) === "true";
        const isGenerated = await prompter.ask(QuestionsKeysEnum.IS_GENERATED) === "true";
        const isUnique = await prompter.ask(QuestionsKeysEnum.IS_UNIQUE) === "true";
        const isNullable = await prompter.ask(QuestionsKeysEnum.IS_NULABLE) === "true";
        const defaultValue = await prompter.ask(QuestionsKeysEnum.DEFAULT_VALUE);
        const column: ColumnDetails = {
            columnName: columnName as string,
            type: columnType as string,
            isPrimary: isPrimary as boolean,
            isGenerated: isGenerated as boolean,
            isUnique: isUnique as boolean,
            nullable: isNullable as boolean,
            default: defaultValue as string,
        };
        // 3. Ajouter la colonne à la liste des colonnes
        columns.push(column);
        // 4. Demander à l'utilisateur s'il veut ajouter plus de colonnes
        moreColumns = await prompter.ask(QuestionsKeysEnum.MORE_COLUMNS) === "true";
    }

// 5. Ajouter les colonnes dans le fichier de définition d'entité prisma
    let prismaFile = 'prisma/schema.prisma'
    let prismaModel = `model ${entityName} {\n`;
    for (const column of columns) {
        prismaModel += `  ${column.columnName} ${column.type}`;
        if (column.isPrimary) {
            prismaModel += ' @id';
        }
        if (column.isGenerated) {
            prismaModel += ' @default(autoincrement())';
        }
        if (column.isUnique) {
            prismaModel += ' @unique';
        }
        if (column.nullable) {
            prismaModel += ' @default(null)';
        }
        if (column.default) {
            prismaModel += ` @default(${column.default})`;
        }
        prismaModel += '\n';
    }
    prismaModel += '}\n';
    appendFileSync(prismaFile, prismaModel);

}