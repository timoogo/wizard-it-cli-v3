import fs from 'fs';
import path from 'path';
import {DefinedLanguage} from "../resources/global/translations.js";
import {
    getSystemLanguage,
    getTranslation, Language,
    setLangToSystem,
} from "../utils/language.utils.js"
import * as console from "console";

export const init = async () => {
    setLangToSystem(); // Définit la langue courante sur la langue système
    const currentLang = getSystemLanguage().langCode; // Récupère la langue système

    const directoryName = "dist/.wizgen";
    const files = ["settings.json", "entity.definition.json"];

    if (!fs.existsSync(directoryName)) {
        fs.mkdirSync(directoryName, { recursive: true });
    }

    for (const file of files) {
        const filePath = path.join(directoryName, file);
        let fileContent = "";

        switch (file) {
            case "settings.json":
                // Création de l'objet avec la structure souhaitée
                const settings = {
                    lang: {
                        fullLanguage: currentLang === Language.FR ? "Français (FR)" : "English (US)",
                        langCode: currentLang,
                    }
                };
                fileContent = JSON.stringify(settings, null, 2);
                break;

            case "entity.definition.json":
                fileContent = "{}";
                break;
        }

        try {
            fs.writeFileSync(filePath, fileContent);
         //   console.log("currentLangResource", getTranslation("FILE_CREATED", "FILE_MANAGEMENT"));
            // foreach translation log it
             console.log("currentLangResource", getTranslation("FILE_CREATED", "FILE_MANAGEMENT"));

        } catch (error) {
            console.error(`Error creating file ${filePath}: ${error}`);
        }
    }
};