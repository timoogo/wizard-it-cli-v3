"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Driver = void 0;
var Driver;
(function (Driver) {
    Driver["MYSQL"] = "mysql";
    Driver["POSTGRES"] = "postgres";
    Driver["MARIADB"] = "mariadb";
})(Driver || (exports.Driver = Driver = {}));
