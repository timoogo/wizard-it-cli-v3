export enum Driver {
    MYSQL = "mysql",
    POSTGRES = "postgres",
    MARIADB = "mariadb",
}