export const SHOW = "show";
export const CREATE = "create";
export const EDIT = "edit";
export const DELETE = "delete";
export const INDEX = "index";
export const ALL = "all";

export const CRUD = [SHOW, CREATE, EDIT, DELETE, INDEX, ALL];
