import {ErrorMessagesEnum, FileManagementKeysEnum, QuestionsKeysEnum} from "../resources/global/translations.js";



// A language enum based on SystemLanguageInfo
export enum Language {
  EN = "en_US",
  FR = "fr_FR",
}
export type LanguageKeys = keyof typeof Language;

// Liste de toutes les langues supportées par la CLI dans un tableau
export const LANGUAGES: Language[] = [Language.EN, Language.FR];

export interface SystemLanguageInfo {
  fullLanguage: string;
  langCode: Language;
}

export enum Separator {
  UNDERSCORE = "_",
  DASH = "-",
}

// Constantes pour les chaînes codées en dur
const DEFAULT_LOCALE = 'en_US';
const LOCALE_FR = 'fr_FR';

export const getSystemLanguage = (): SystemLanguageInfo => {
    const fullLanguage = process.env.LANG || DEFAULT_LOCALE;
    const langCode = fullLanguage.includes(LOCALE_FR) ? Language.FR : Language.EN;
    return {fullLanguage, langCode};
};

export type Questions = Record<string, string>;
export type ErrorMessages = Record<string, string>;
export type FileManagement = Record<string, string>;

interface Resources {
  [key: string]: Record<string, string>;
}

interface Resource {
  [key: string]: string;
}

// Ici, vous devriez remplir les ressources linguistiques pour chaque langue.
const LANGUAGE_RESOURCES: Record<Language, Resources> = {
  [Language.EN]: {
    QUESTIONS: {
      ...QuestionsKeysEnum, // Intégration des questions
      // Vos questions en anglais
    },
    ERROR_MESSAGES: {
      ...ErrorMessagesEnum, // Intégration des messages d'erreur
      // Autres messages d'erreur spécifiques en anglais
    },
    FILE_MANAGEMENT: {
      ...FileManagementKeysEnum, // Intégration des messages de gestion de fichiers
      // Autres messages de gestion de fichiers spécifiques en anglais
    },
  },
  [Language.FR]: {
    QUESTIONS: {
      // Vos questions en français
    },
    ERROR_MESSAGES: {
      ...QuestionsKeysEnum, // Traduisez ces messages en français
      // Autres messages d'erreur spécifiques en français
    },
    FILE_MANAGEMENT: {
      ...FileManagementKeysEnum, // Traduisez ces messages en français
      // Autres messages de gestion de fichiers spécifiques en français
    },
  },
};

let currentLang: Language = getSystemLanguage().langCode;

export const getCurrentLang = (): Language => {
  return currentLang;
};

export const setCurrentLang = (targetedLang: Language): void => {
  currentLang = targetedLang;
};

export const setLangToSystem = () => {
  console.log(`Setting language to system language: ${getSystemLanguage().langCode}`);
 return  currentLang = getSystemLanguage().langCode;
};

// Exemple de vérification dans getTranslation
export function getTranslation(key: string, resourceType: keyof Resources): string | undefined {
    const resources = LANGUAGE_RESOURCES[currentLang];
    if (!resources || !resources[resourceType]) {
      console.error(`No resources found for language: ${currentLang} or resource type: ${resourceType}`);
      return undefined;
  }

  // Utilisation d'une assertion de type pour accéder à la ressource
  const resource = resources[resourceType] as Resource;
  // Vérification de la clé dans la ressource
    if (!resource[key]) {
        console.error(`No translation found for key: ${key}`);
        return undefined;
    }
  console.log(`Translation found for key: ${key}, resource[key] ===  ${resource[key]}`)
  return resource[key];
}


export function getQuestionTranslation(key: string): string {
  return getTranslation(key, "QUESTIONS") || '';
}

export function getErrorMessageTranslation(key: string): string {
  return getTranslation(key, "ERROR_MESSAGES") || '';
}
export function getFileManagementTranslation(key: string): string {
  return getTranslation(key, "FILE_MANAGEMENT") || '';
}
export enum StringType {
  CamelCase,
  CapitalizedCase,
  SpacesToUnderscores,
  CamelCaseToUnderscores
}

