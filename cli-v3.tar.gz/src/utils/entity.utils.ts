import * as fs from 'fs';
import { ColumnDetails } from './Column.details.interface.js';

const WIZGEN_FOLDER = "dist/.wizgen";
const WIZGEN_ENTITY_DEFINITION_FILE = 'entity.definition.json';
const WIZGEN_ENTITY_DEFINITION_FILE_PATH = `${WIZGEN_FOLDER}/${WIZGEN_ENTITY_DEFINITION_FILE}`;
export function listEntities() {
    // Lire le contenu du fichier
    const rawData = fs.readFileSync(WIZGEN_ENTITY_DEFINITION_FILE_PATH, 'utf-8');
    
    // Analyser le contenu pour obtenir un objet JavaScript
    const entitiesData = JSON.parse(rawData);
    
    // Extraire les noms des entités
    return entitiesData.entities.map((entity: ColumnDetails) => entity.field);
}

export function loadSchemaFromEntityName(entityName: string) {
    // Lire le contenu du fichier
    const rawData = fs.readFileSync(WIZGEN_ENTITY_DEFINITION_FILE_PATH, 'utf-8');

    // Analyser le contenu pour obtenir un objet JavaScript
    const entitiesData = JSON.parse(rawData);

    // trouver l'entité correspondante au nom de l'entité donné en paramètre
    const entity = entitiesData.entities.find((entity: ColumnDetails) => entity.field === entityName);

    if (entity) {
        return entity;
    } else {
        return null;
    }

}   