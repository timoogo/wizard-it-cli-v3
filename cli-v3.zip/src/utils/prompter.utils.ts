import inquirer, {InputQuestion, Question, Answers, PasswordQuestion} from 'inquirer';
import { QuestionKeys, QUESTIONS } from '../resources/en/en.resource.js';
import {ListOrCheckboxQuestion, QuestionType} from './Questions.type.js';
import * as fs from "fs";
import { Language } from './language.utils.js';


interface CustomQuestion {
    type: QuestionType;
    message: string;
    choices?: string[];  // Seulement pertinent pour 'list' et 'checkbox'
}

export class Prompter {
    private language: Language;

    constructor(language: Language = Language.EN) {
        this.language = language;
        // Directly use QUESTIONS from the imported resource
    }

    public async ask(questionKey: QuestionKeys, defaultValue?: string): Promise<string | undefined | null> {
        try {
            const questionData = QUESTIONS[String(questionKey)];

            if (!questionData) {
                console.warn(`Unknown question key: ${questionKey}`);
                return null;
            }

            let finalInquirerQuestion: Question;

            switch (questionData.type) {
                case 'list':


                case 'checkbox':
                    if ('choices' in questionData) {
                        finalInquirerQuestion = {
                            type: questionData.type,
                            name: 'response',
                            message: questionData.message,
                            choices: questionData.choices,
                            default: questionData.default,
                        } as ListOrCheckboxQuestion;
                    } else {
                        // Assign a default question type in case there are no choices
                        finalInquirerQuestion = {
                            type: 'input',
                            name: 'response',
                            message: questionData.message,
                            default: defaultValue || questionData.default,
                        } as InputQuestion;
                    }
                    break;
                case 'password':
                    finalInquirerQuestion = {
                        type: 'password',
                        name: 'response',
                        message: questionData.message,
                        mask: '*',  // You can adjust this as per your requirement
                    } as PasswordQuestion;  // Assuming you have a type named PasswordQuestion
                    break;
                default:
                    finalInquirerQuestion = {
                        type: 'input',
                        name: 'response',
                        message: questionData.message,
                        default: defaultValue || questionData.default,
                    } as InputQuestion;
                    break;
            }

            const answer: Answers = await inquirer.prompt([finalInquirerQuestion]);
            return answer.response;

        } catch (error) {
            console.error("Une erreur s'est produite lors de la pose de la question :", { error });
        }
    }


    /**
     * Get all created entities from the .wizgen/entity.definition.json file
     * @returns a list of entity names
     **/
    public get entities() {
        const content = fs.readFileSync('dist/.wizgen/entity.definition.json', 'utf-8');
        const entityDefinitionPath = 'dist/.wizgen/entity.definition.json';
        if (!fs.existsSync(entityDefinitionPath)) {
            return [];
        }
        else {
            // read the file
            fs.readFileSync(entityDefinitionPath, 'utf-8');
            // parse the file
            const data = JSON.parse(content);

        }
        return ''
    }

    /**
     * 
     * @param questionKeys 
     * @returns 
     */

    public async askMultiple(questionKeys: QuestionKeys[]): Promise<Record<string, any>> {
        const responses: Record<string, any> = {};
        for (const key of questionKeys) {
            responses[key] = await this.ask(key);
        }
        return responses;
    }
}
