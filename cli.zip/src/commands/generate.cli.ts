import * as fs from "fs";
import * as path from "path";
import { Prompter } from "../utils/prompter.utils.js";
import { QuestionsKeysEnum} from '../resources/en/en.resource.js';
import { ColumnDetails } from "../utils/Column.details.interface.js";
import { loadSchemaFromEntityName } from "../utils/entity.utils.js";
import { DEFAULT_PROPERTIES } from "../utils/default.properties.js"
import { ALL } from "../resources/constants/crud.constant.js";
import { ENTITIES_NAME_SAMPLES } from "../resources/constants/samples.constant.js";
import {Driver} from "../resources/constants/drivers.constant.js";
import { execSync } from 'child_process';
// import pg
import pkg from 'pg';
import {directoryName} from "@/resources/constants/utils.constant.js";
const { Client } = pkg;

const WIZGEN_FOLDER = 'dist/.wizgen';
const WIZGEN_ENTITY_DEFINITION_FILE = 'entity.definition.json';

interface EntityDefinition {
    entities: Entity[];
    version: number;
}

interface Entity {
    entityName: string;
    columns: ColumnDetails[];
}

const useDefaultProperties = async (prompter: Prompter): Promise<ColumnDetails[]> => {
    const useDefaults = await prompter.ask(QuestionsKeysEnum.CONFIRM_DEFAULT_PROPERTIES) === 'yes';
    if (useDefaults) {
        return Object.values(DEFAULT_PROPERTIES).filter(prop => prop !== null && prop !== undefined) as ColumnDetails[];
    }
    return [];
};


const getColumnDetails = async (prompter: Prompter): Promise<ColumnDetails[]> => {
    let columns: ColumnDetails[] = [];
    let addMoreColumns = true;

    while (addMoreColumns) {
        const columnName = await prompter.ask(QuestionsKeysEnum.COLUMN_NAME);

        if (columnName && DEFAULT_PROPERTIES.hasOwnProperty(columnName)) {
            const columnProperty = DEFAULT_PROPERTIES[columnName];
            if (columnProperty) {
                columns.push(columnProperty as ColumnDetails);
            }
        } else {
            const columnType = await prompter.ask(QuestionsKeysEnum.COLUMN_TYPE);
            const isPrimary = await prompter.ask(QuestionsKeysEnum.IS_PRIMARY) === 'yes';
            const isGenerated = await prompter.ask(QuestionsKeysEnum.IS_GENERATED) === 'yes';
            const isUnique = await prompter.ask(QuestionsKeysEnum.IS_UNIQUE) === 'yes';
            const isNullable = await prompter.ask(QuestionsKeysEnum.IS_NULABLE) === 'yes';

            columns.push(<ColumnDetails>{
                columnName: columnName,
                type: columnType,
                isPrimary,
                isGenerated,
                isUnique,
                nullable: isNullable,
                default: ""
            });
        }

        addMoreColumns = await prompter.ask(QuestionsKeysEnum.MORE_COLUMNS) === 'yes';
    }

    return columns;
};

const saveEntityDefinition = async (data: EntityDefinition, entityDefinitionPath: string): Promise<void> => {
    const saveToJson = await (new Prompter()).ask(QuestionsKeysEnum.SAVE_TO_JSON) === 'yes';
    if (saveToJson) {
        fs.writeFileSync(entityDefinitionPath, JSON.stringify(data, null, 4));
        console.log("Entity generated:", `${WIZGEN_FOLDER}/${WIZGEN_ENTITY_DEFINITION_FILE}`);
    }
};

export const createEntityDefinition = async (): Promise<void> => {
    const prompter = new Prompter();

    // Step 1: Check if the entity.definition.json file exists
    const entityDefinitionPath = path.join(WIZGEN_FOLDER, WIZGEN_ENTITY_DEFINITION_FILE);
    let data: EntityDefinition = {
        entities: [],
        version: 1
    };

    if (fs.existsSync(entityDefinitionPath)) {
        const content = fs.readFileSync(entityDefinitionPath, 'utf-8');
        data = JSON.parse(content);
        data.version++;
    }

    // Ask for the entity name
    const randomIndex = Math.floor(Math.random() * ENTITIES_NAME_SAMPLES.length);
    const entityName = await prompter.ask(QuestionsKeysEnum.ENTITY_NAME, ENTITIES_NAME_SAMPLES[randomIndex]);
    if (!entityName) {
        console.error("Le nom de l'entité n'est pas défini.");
        return;
    }

    const columns = [...await useDefaultProperties(prompter), ...await getColumnDetails(prompter)];

    const entity: Entity = {
        entityName: entityName,
        columns: columns
    };
    data.entities.push(entity);

    await saveEntityDefinition(data, entityDefinitionPath);
};

const appendEntityDefinition = async (): Promise<void> => {
    const prompter = new Prompter();

    const entityDefinitionPath = path.join(WIZGEN_FOLDER, WIZGEN_ENTITY_DEFINITION_FILE);
    let data: EntityDefinition;
    if (fs.existsSync(entityDefinitionPath)) {
        const content = fs.readFileSync(entityDefinitionPath, 'utf-8');
        data = JSON.parse(content);
    } else {
        console.error("Entity definition file does not exist. Consider creating a new entity first.");
        return;
    }

    const entityNames = data.entities.map(entity => entity.entityName);
    const selectedEntityName = await prompter.ask(QuestionsKeysEnum.SELECT_ENTITY, {
        choices: entityNames
    });

    const selectedEntity = data.entities.find(entity => entity.entityName === selectedEntityName);

    if (!selectedEntity) {
        console.error("Selected entity not found.");
        return;
    }

    const columns = [...await useDefaultProperties(prompter), ...await getColumnDetails(prompter)];

    selectedEntity.columns.push(...columns);

    await saveEntityDefinition(data, entityDefinitionPath);
};

export const testPostgresConnection = async (connectionString: string): Promise<boolean> => {
    const client = new Client({
        connectionString: connectionString
    });

    try {
        await client.connect();
        console.log('Connexion à PostgreSQL réussie !');
        await client.end();
        return true;
    } catch (error) {
        console.error('Erreur lors de la connexion à PostgreSQL :', error);
        return false;
    }
};
export const generateEnv = async () => {
    const prompter = new Prompter();
    let isConnected = false;
    let databaseName, driver, hostName, userName, password, port;

    while (!isConnected) {
        databaseName = await prompter.ask(QuestionsKeysEnum.DATABASE_NAME);
        driver = await prompter.ask(QuestionsKeysEnum.SELECT_DRIVER);

        if (driver === Driver.POSTGRES) {
            hostName = await prompter.ask(QuestionsKeysEnum.HOST_NAME, 'localhost');
            userName = await prompter.ask(QuestionsKeysEnum.USER_NAME, 'postgres');
            password = await prompter.ask(QuestionsKeysEnum.PASSWORD, 'root');
            port = await prompter.ask(QuestionsKeysEnum.PORT, '5432');
        }

        if (driver === Driver.POSTGRES) {
            const testConnectionString = `postgresql://${userName}:${password}@${hostName}:${port}/postgres`;
            const client = new Client({ connectionString: testConnectionString });
            try {
                await client.connect();
                isConnected = true;
                await client.end();
                console.log("Connexion réussie à PostgreSQL !");
            } catch (e) {
                console.error("Erreur lors de la connexion à PostgreSQL :", e);
                console.log("Veuillez entrer à nouveau les informations de connexion.");
            }
        }
    }

    const createDbClient = new Client({
        connectionString: `postgresql://${userName}:${password}@${hostName}:${port}/postgres`
    });
    await createDbClient.connect();

    // Vérifier si la base de données existe
    const dbExists = await createDbClient.query(`SELECT datname FROM pg_database WHERE datname = '${databaseName}';`);
    if (dbExists.rows.length > 0) {
        const replaceConfirm = await prompter.ask(QuestionsKeysEnum.CONFIRM_DELETE_DATABASE);
        if (!replaceConfirm) {
            console.log("Base de données existante non remplacée. Opération terminée.");
            await createDbClient.end();
            return;
        }
        await createDbClient.query(`DROP DATABASE ${databaseName};`);
    }

    await createDbClient.query(`CREATE DATABASE ${databaseName};`);
    console.log(`Base de données '${databaseName}' créée avec succès !`);
    await createDbClient.end();

    const envPath = path.join(process.cwd(), '.env');

    let connectionString = '';
    switch (driver) {
        case Driver.MYSQL:
            connectionString = `DATABASE_URL="mysql://${userName}:${password}@${hostName}:${port}/${databaseName}"\n`;
            break;
        case Driver.POSTGRES:
            connectionString = `DATABASE_URL="postgresql://${userName}:${password}@${hostName}:${port}/${databaseName}?schema=public"\n`;
            break;
        case Driver.MARIADB:
            connectionString = `DATABASE_URL="mariadb://${userName}:${password}@${hostName}:${port}/${databaseName}"\n`;
            break;
        default:
            console.log('Driver non reconnu.');
            return;
    }

    // Lisez le contenu existant du fichier .env
    let existingContent = fs.readFileSync(envPath, 'utf-8');

    // Supprimez l'ancienne chaîne de connexion DATABASE_URL si elle existe
    const databaseUrlRegex = /^DATABASE_URL=.*$/m;
    if (databaseUrlRegex.test(existingContent)) {
        existingContent = existingContent.replace(databaseUrlRegex, connectionString);
    } else {
        // Si DATABASE_URL n'existe pas, ajoutez simplement la nouvelle chaîne de connexion à la fin
        existingContent += `\n${connectionString}\n`;
    }

    // Écrivez le contenu mis à jour dans le fichier .env
    fs.writeFileSync(envPath, existingContent);
    console.log(`Chaîne de connexion pour ${driver} ajoutée ou mise à jour dans le fichier .env.`);

    console.log(existingContent);
};
export async function generatePanel() {
    const prompter = new Prompter();
    console.log('Génération d\'un panneau pour une entité spécifique dans une application Next.js');
    // 1. Interroger l'utilisateur sur l'entité pour laquelle générer un panel
    const selectedEntity = await prompter.ask(QuestionsKeysEnum.SELECT_ENTITY);

    // 2. Vérifier si le schéma de l'entité existe
    const schema = loadSchemaFromEntityName(selectedEntity) // Chargez le schéma depuis le fichier JSON

    if (!schema) {
        console.error(`No schema found for entity: ${selectedEntity}`);
        return;
    }

    // 3. Poser une série de questions pour configurer le panel
    const panelName = await prompter.ask(QuestionsKeysEnum.PANEL_NAME, selectedEntity as string);
    const entryPoint = await prompter.ask(QuestionsKeysEnum.ENTRY_POINT, `/${selectedEntity}`);
    const pagesToGenerate = await prompter.ask(QuestionsKeysEnum.PAGES_TO_GENERATE, ALL);

    // 4. Créer les fichiers et dossiers nécessaires
    // 4.1. Créer le dossier du panneau dans le dossier des pages
    // 4.2. Créer le dossier du panneau dans le dossier des composants
    // 4.3. Créer le dossier du panneau dans le dossier des modèles
    



    // il rentre dans /template
    // 5. Copiez les fichiers/ dossiers de modèle dans le dossier de destination (dist/.wizgen/templates/{panelName})
    // 6. Remplacez les variables dans les fichiers de modèle par les valeurs fournies par l'utilisateur

    //
}


export const generateDb = () => {
    try {
        console.log('Génération du fichier de migration...');
        execSync('prisma migrate dev --name init', { stdio: 'inherit' });

        console.log('La base de données a été générée avec succès.');
    } catch (error) {
        console.error('Erreur lors de la génération de la base de données:', error);
    }
};